const express = require('express')
const router = express.Router()
const Article = require('../models/Article')

module.exports = router

//Getting all
router.get('/', async(req,res)=>{
    try{
        const Articles = await Article.find()
        res.json(Articles)
    }catch{
        res.status(500).json({message: err.message})
    }
})

//Getting one
router.get('/:id', getArticle, (req,res)=>{
    res.json(res.article)
})

//Creating one
router.post('/', async (req,res)=>{
    const article = new Article({

        Article_no: req.body.Article_no,
        Article_short_description: req.body.Article_short_description,
        Article_body: req.body.Article_body,
        Article_source: req.body.Article_source,
        Article_URL: req.body.Article_URL,
        Location: req.body.Location,
        Article_keywords: req.body.Article_keywords,
        Article_weight: req.body.Article_weight,
        Article_citations: req.body.Article_citations
    })
    try{
        const newArticle = await article.save()
        res.status(201).json(newArticle)
    }catch (err){
        res.status(400).json({message: err.message})
    }

})

//Updating one
router.patch('/:id', getArticle, async (req,res)=>{
    if(req.body.Article_no != null){
        res.article.Article_no = req.body.Article_no
    }
    if(req.body.Article_short_description != null){
        res.article.Article_short_description = res.body.Article_short_description
    }
    if(req.body.Article_body != null){
        res.article.Article_body = req.body.Article_body
    }
    if(req.body.Article_source != null){
        res.article.Article_source = req.body.Article_source
    }
    if(req.body.Article_URL != null){
        res.article.Article_URL = req.body.Article_URL
    }
    if(req.body.Location != null){
        res.article.Location = req.body.Location
    }
    if(req.body.Article_keywords != null){
        res.article.Article_keywords = req.body.Article_keywords
    }
    if(req.body.Article_weight != null){
        res.article.Article_weight = req.body.Article_weight
    }
    if(req.body.Article_citations != null){
        res.article.Article_citations = req.body.Article_citations
    }
    try{
        const updatedArticle = await res.article.save()
        res.json(updatedArticle)
    }catch(err){
        res.status(400).json({message: err.message})
    }
})

//Deleting one
router.delete('/:id', getArticle, async(req,res)=>{
    try{
        await res.article.remove()
        res.json({message:'Deleted article'})
    }catch(err){
        res.status(500).json({message: err.message})
    }
})    
async function getArticle(req,res,next){
    let article
    try{
        article = await Article.findById(req.params.id)
        if (article == null){
            return res.status(404).json({message: 'Cannot find article'})
        }
    }catch(err){
        return res.status(500).json({message: err.message})
    }
    res.article = article
    next()
}
module.exports = router