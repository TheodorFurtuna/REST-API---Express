const express = require('express')
const router = express.Router()
const Token = require('../models/Token')

module.exports = router

//Getting all
router.get('/', async(req,res)=>{
    try{
        const Tokens = await Token.find()
        res.json(Tokens)
    }catch{
        res.status(500).json({message: err.message})
    }
})

//Getting one
router.get('/:id', getToken, (req,res)=>{
    res.json(res.Token)
})

//Creating one
router.post('/', async (req,res)=>{
    const token = new Token({
        Token_body: req.body.Token_body
    })
    try{
        const newToken = await token.save()
        res.status(201).json(newToken)
    }catch (err){
        res.status(400).json({message: err.message})
    }

})

//Updating one
router.patch('/:id', getToken, async (req,res)=>{
    if(req.body.Token_body != null){
        res.Token.Token_body = req.body.Token_body
    }
    try{
        const updatedToken = await res.Token.save()
        res.json(updatedToken)
    }catch(err){
        res.status(400).json({message: err.message})
    }
})

//Deleting one
router.delete('/:id', getToken, async(req,res)=>{
    try{
        await res.Token.remove()
        res.json({message:'Deleted token'})
    }catch(err){
        res.status(500).json({message: err.message})
    }
})    
async function getToken(req,res,next){
    let token
    try{
        token = await Token.findById(req.params.id)
        if (Token == null){
            return res.status(404).json({message: 'Cannot find token'})
        }
    }catch(err){
        return res.status(500).json({message: err.message})
    }
    res.Token = token
    next()
}
module.exports = router