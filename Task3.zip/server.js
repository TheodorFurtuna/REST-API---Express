require('dotenv').config()
const express = require('express')
const mongoose = require('mongoose')
const app = express()

mongoose.connect(process.env.DATABASE_URL, {useNewUrlParser:true})
const db = mongoose.connection
db.on ('error', (error) => console.error(error))
db.once ('open', () => console.log('Connected to database'))

app.use(express.json())

const ArticlesRouter = require('./routes/Articles')
app.use('/Articles', ArticlesRouter)

const CategoriesRouter = require('./routes/Categories')
app.use('/Categories', CategoriesRouter)

const TokensRouter = require('./routes/Tokens')
app.use('/Tokens', TokensRouter)

app.listen(3000, ()=> console.log('server started'))