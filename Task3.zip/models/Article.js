const mongoose = require('mongoose')

const ArticlesSchema = new mongoose.Schema({
    Article_no: {
        type: String,
        required: true
    },
    Article_short_description: {
        type: String,
        required: true
    },
    Article_date: {
        type: Date,
        required: true,
        default: Date.now
    },  
    Collection_date: {
        type: Date,
        required: true,
        default: Date.now
    }, 
    Article_body: {
        type: String,
        required: true
    },
    Article_source: {
        type: String,
        required: true
    },
    Article_URL: {
        type: String,
        required: true
    },
    Location: {
        type: String,
        required: true
    },
    Article_keywords: {
        type: String,
        required: true
    },
    Article_weight: {
        type: String,
        required: true
    },
    Article_citations: {
        type: String,
        required: true
    },
    Tokens:[{type:mongoose.Schema.Types.ObjectId, ref:'Tokens'}],
    Categories:[{type:mongoose.Schema.Types.ObjectId, ref:'Categories'}]
})
module.exports = mongoose.model('Article', ArticlesSchema)