const mongoose = require('mongoose')

const CategoriesSchema = new mongoose.Schema({
    Categories_name: {
        type: String,
        required: true
    }
})
module.exports = mongoose.model('Category', CategoriesSchema)